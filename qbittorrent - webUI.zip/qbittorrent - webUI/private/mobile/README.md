# MD-qBittorrent-web-ui
基于 MDUI 前端框架设计的手机专属 qBittorrent WEB UI（后续会做电脑版），涵盖了 70% 官方 WEB UI 能做到的功能
