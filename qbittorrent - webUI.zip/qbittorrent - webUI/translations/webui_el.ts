<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS language="el" version="2.1">
<context>
    <name>AboutDlg</name>
    <message>
        <source>About</source>
        <translation>Σχετικά</translation>
    </message>
</context>
<context>
    <name>AddNewTorrentDialog</name>
    <message>
        <source>Category:</source>
        <translation>Κατηγορία:</translation>
    </message>
    <message>
        <source>Start torrent</source>
        <translation>Έναρξη torrent</translation>
    </message>
    <message>
        <source>Skip hash check</source>
        <translation>Παράλειψη ελέγχου hash</translation>
    </message>
    <message>
        <source>Create subfolder</source>
        <translation>Δημιουργία υποφακέλου</translation>
    </message>
    <message>
        <source>Torrent Management Mode:</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>CategoryFilterModel</name>
    <message>
        <source>All</source>
        <translation>Όλα</translation>
    </message>
    <message>
        <source>Uncategorized</source>
        <translation>Χωρίς κατηγορία</translation>
    </message>
</context>
<context>
    <name>CategoryFilterWidget</name>
    <message>
        <source>Add category...</source>
        <translation>Προσθήκη κατηγορίας...</translation>
    </message>
    <message>
        <source>Remove category</source>
        <translation>Αφαίρεση κατηγορίας</translation>
    </message>
    <message>
        <source>Remove unused categories</source>
        <translation>Αφαίρεση αχρησιμοποίητων κατηγοριών</translation>
    </message>
    <message>
        <source>Resume torrents</source>
        <translation>Συνέχιση torrents</translation>
    </message>
    <message>
        <source>Pause torrents</source>
        <translation>Παύση torrents</translation>
    </message>
    <message>
        <source>Delete torrents</source>
        <translation>Διαγραφή torrents</translation>
    </message>
    <message>
        <source>New Category</source>
        <translation>Νέα κατηγορία</translation>
    </message>
    <message>
        <source>Edit category...</source>
        <translation>Επεξεργασία κατηγορίας...</translation>
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <source>Exit qBittorrent</source>
        <translation>Έξοδος qBittorrent</translation>
    </message>
    <message>
        <source>Only one link per line</source>
        <translation>Μόνο ένας σύνδεσμος ανά γραμμή</translation>
    </message>
    <message>
        <source>Global upload rate limit must be greater than 0 or disabled.</source>
        <translation>Το όριο του γενικού ρυθμού αποστολής πρέπει να είναι μεγαλύτερο από 0 ή απενεργοποιημένο.</translation>
    </message>
    <message>
        <source>Global download rate limit must be greater than 0 or disabled.</source>
        <translation>Το όριο του γενικού ρυθμού λήψης πρέπει να είναι μεγαλύτερο από 0 ή απενεργοποιημένο.</translation>
    </message>
    <message>
        <source>Alternative upload rate limit must be greater than 0 or disabled.</source>
        <translation>Το όριο του εναλλακτικού ρυθμού αποστολής πρέπει να είναι μεγαλύτερο από 0 ή απενεργοποιημένο.</translation>
    </message>
    <message>
        <source>Alternative download rate limit must be greater than 0 or disabled.</source>
        <translation>Το όριο του εναλλακτικού ρυθμού λήψης πρέπει να είναι μεγαλύτερο από 0 ή απενεργοποιημένο.</translation>
    </message>
    <message>
        <source>Maximum active downloads must be greater than -1.</source>
        <translation>Οι μέγιστη ενεργές λήψεις θα πρέπει να είναι μεγαλύτερες από -1.</translation>
    </message>
    <message>
        <source>Maximum active uploads must be greater than -1.</source>
        <translation>Οι μέγιστη ενεργές αποστολές θα πρέπει να είναι μεγαλύτερες από -1.</translation>
    </message>
    <message>
        <source>Maximum active torrents must be greater than -1.</source>
        <translation>Τα μέγιστα ενεργά torrents θα πρέπει να είναι μεγαλύτερα από -1.</translation>
    </message>
    <message>
        <source>Maximum number of connections limit must be greater than 0 or disabled.</source>
        <translation>Το όριο μέγιστου αριθμού συνδέσεων πρέπει να είναι μεγαλύτερο από 0 ή απενεργοποιημένο.</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent limit must be greater than 0 or disabled.</source>
        <translation>Το όριο μέγιστου αριθμού συνδέσεων ανά torrent πρέπει να είναι μεγαλύτερο από 0 ή απενεργοποιημένο.</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</source>
        <translation>Το όριο μέγιστου αριθμού θέσεων αποστολής ανά torrent πρέπει να είναι μεγαλύτερο από 0 ή απενεργοποιημένο.</translation>
    </message>
    <message>
        <source>Unable to save program preferences, qBittorrent is probably unreachable.</source>
        <translation>Δεν είναι δυνατή η αποθήκευση των προτιμήσεων του προγράμματος, το qBittorrent είναι πιθανώς απρόσιτο.</translation>
    </message>
    <message>
        <source>IRC: #qbittorrent on Freenode</source>
        <translation>IRC: #qbittorrent στο Freenode</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Άγνωστο</translation>
    </message>
    <message>
        <source>Share ratio limit must be between 0 and 9998.</source>
        <translation>Το κοινό όριο αναλογίας πρέπει να είναι μεταξύ 0 και 9998.</translation>
    </message>
    <message>
        <source>Seeding time limit must be between 0 and 525600 minutes.</source>
        <translation>Το χρονικό όριο διαμοιρασμού πρέπει να είναι μεταξύ 0 και 525600 λεπτών.</translation>
    </message>
    <message>
        <source>The port used for incoming connections must be between 1 and 65535.</source>
        <translation>Η θύρα που χρησιμοποιείται για εισερχόμενες συνδέσεις θα πρέπει να είναι μεταξύ 1 και 65535.</translation>
    </message>
    <message>
        <source>The port used for the Web UI must be between 1 and 65535.</source>
        <translation>Η θύρα που χρησιμοποιείται για το UI Ιστού θα πρέπει να είναι μεταξύ 1 και 65535.</translation>
    </message>
    <message>
        <source>Unable to log in, qBittorrent is probably unreachable.</source>
        <translation>Αδυναμία σύνδεσης, το qBittorrent είναι πιθανώς απρόσιτο.</translation>
    </message>
    <message>
        <source>Invalid Username or Password.</source>
        <translation>Μη έγκυρο Όνομα Χρήστη ή Κωδικός Πρόσβασης.</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Όνομα χρήστη</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Κωδικός Πρόσβασης</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Σύνδεση</translation>
    </message>
    <message>
        <source>Original authors</source>
        <translation>Αρχικοί δημιουργοί</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Εφαρμογή</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Προσθήκη</translation>
    </message>
    <message>
        <source>Upload Torrents</source>
        <comment>Upload torrent files to qBittorent using WebUI</comment>
        <translation>Μεταφόρτωση Torrents</translation>
    </message>
    <message>
        <source>Save files to location:</source>
        <translation>Αποθήκευση αρχείων στην τοποθεσία:</translation>
    </message>
    <message>
        <source>Cookie:</source>
        <translation>Cookie:</translation>
    </message>
    <message>
        <source>Type folder here</source>
        <translation>Πληκτρολογήστε την πλήρες διαδρομή του φακέλου εδώ</translation>
    </message>
    <message>
        <source>More information</source>
        <translation>Περισσότερες πληροφορίες</translation>
    </message>
    <message>
        <source>Information about certificates</source>
        <translation>Πληροφορίες σχετικά με τα πιστοποιητικά</translation>
    </message>
    <message>
        <source>Set location</source>
        <translation>Ορισμός θέσης</translation>
    </message>
    <message>
        <source>Limit upload rate</source>
        <translation>Όριο ταχύτητας αποστολής...</translation>
    </message>
    <message>
        <source>Limit download rate</source>
        <translation>Όριο ταχύτητας λήψης...</translation>
    </message>
    <message>
        <source>Rename torrent</source>
        <translation>Μετονομασία του torrent</translation>
    </message>
    <message>
        <source>Other...</source>
        <comment>Save Files to: Watch Folder / Default Folder / Other...</comment>
        <translation>Άλλο...</translation>
    </message>
    <message>
        <source>Monday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Δευτέρα</translation>
    </message>
    <message>
        <source>Tuesday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Τρίτη</translation>
    </message>
    <message>
        <source>Wednesday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Τετάρτη</translation>
    </message>
    <message>
        <source>Thursday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Πέμπτη</translation>
    </message>
    <message>
        <source>Friday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Παρασκευή</translation>
    </message>
    <message>
        <source>Saturday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Σάββατο</translation>
    </message>
    <message>
        <source>Sunday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Κυριακή</translation>
    </message>
    <message>
        <source>Logout</source>
        <translation>Αποσύνδεση</translation>
    </message>
    <message>
        <source>Download Torrents from their URLs or Magnet links</source>
        <translation>Λήψη Torrents από τα URL ή τους συνδέσμους Magnet τους</translation>
    </message>
    <message>
        <source>Upload local torrent</source>
        <translation>Μεταφόρτωση τοπικού torrent</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the selected torrents from the transfer list?</source>
        <translation>Είστε σίγουρος ότι θέλετε να διαγράψετε τα επιλεγμένα torrent από την λίστα μεταφοράς?</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Αποθήκευση</translation>
    </message>
    <message>
        <source>qBittorrent client is not reachable</source>
        <translation>Ο πελάτης qBittorrent δεν είναι προσβάσιμος</translation>
    </message>
    <message>
        <source>Global number of upload slots limit must be greater than 0 or disabled.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Invalid category name:\nPlease do not use any special characters in the category name.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Unable to create category</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Upload rate threshold must be greater than 0.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Edit</source>
        <translation>Επεξεργασία</translation>
    </message>
    <message>
        <source>Free space: %1</source>
        <translation>Ελεύθερος χώρος: %1</translation>
    </message>
    <message>
        <source>Torrent inactivity timer must be greater than 0.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Saving Management</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Download rate threshold must be greater than 0.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>qBittorrent has been shutdown</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>JavaScript Required! You must enable JavaScript for the Web UI to work properly</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Edit</source>
        <translation>Επεξεργασία</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation>Εργαλεία</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Αρχείο</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Βοήθεια</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Προβολή</translation>
    </message>
    <message>
        <source>Options...</source>
        <translation>Επιλογές…</translation>
    </message>
    <message>
        <source>Resume</source>
        <translation>Συνέχιση</translation>
    </message>
    <message>
        <source>Minimum Priority</source>
        <translation>Ελάχιστη Προτεραιότητα</translation>
    </message>
    <message>
        <source>Top Priority</source>
        <translation>Μέγιστη προτεραιότητα</translation>
    </message>
    <message>
        <source>Decrease Priority</source>
        <translation>Μείωση προτεραιότητας</translation>
    </message>
    <message>
        <source>Increase Priority</source>
        <translation>Αύξηση προτεραιότητας</translation>
    </message>
    <message>
        <source>Top Toolbar</source>
        <translation>Κορυφαία Γραμμή εργαλείων</translation>
    </message>
    <message>
        <source>Status Bar</source>
        <translation>Γραμμή κατάστασης</translation>
    </message>
    <message>
        <source>Speed in Title Bar</source>
        <translation>Ταχύτητα στην Γραμμή Τίτλου</translation>
    </message>
    <message>
        <source>Donate!</source>
        <translation>Δωρεά!</translation>
    </message>
    <message>
        <source>Resume All</source>
        <translation>Συνέχιση Όλων</translation>
    </message>
    <message>
        <source>Statistics</source>
        <translation>Στατιστικά</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Σχετικά</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation>Παύση</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Διαγραφή</translation>
    </message>
    <message>
        <source>Pause All</source>
        <translation>Παύση Όλων</translation>
    </message>
    <message>
        <source>Add Torrent File...</source>
        <translation>Προσθήκη Αρχείου Torrent…</translation>
    </message>
    <message>
        <source>Documentation</source>
        <translation>Τεκμηρίωση</translation>
    </message>
    <message>
        <source>Add Torrent Link...</source>
        <translation>Προσθήκη Σύνδεσμου Torrent…</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Ναι</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Όχι</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation>Γενικό Όριο Ταχύτητας Αποστολής</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation>Γενικό Όριο Ταχύτητας Λήψης</translation>
    </message>
    <message>
        <source>Are you sure you want to quit qBittorrent?</source>
        <translation>Είστε σίγουροι ότι θέλετε να κλείσετε το qBittorrent?</translation>
    </message>
    <message>
        <source>[D: %1, U: %2] qBittorrent %3</source>
        <comment>D = Download; U = Upload; %3 is qBittorrent version</comment>
        <translation>[Λ: %1, Α: %2] qBittorrent %3</translation>
    </message>
    <message>
        <source>Alternative speed limits</source>
        <translation>Εναλλακτικά όρια ταχύτητας</translation>
    </message>
    <message>
        <source>Search Engine</source>
        <translation>Μηχανή αναζήτησης</translation>
    </message>
    <message>
        <source>Filter torrent list...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Search</source>
        <translation>Αναζήτηση</translation>
    </message>
    <message>
        <source>Transfers</source>
        <translation>Μεταφορές</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Επιλογές</translation>
    </message>
    <message>
        <source>Downloads</source>
        <translation>Λήψεις</translation>
    </message>
    <message>
        <source>Connection</source>
        <translation>Σύνδεση</translation>
    </message>
    <message>
        <source>Speed</source>
        <translation>Ταχύτητα</translation>
    </message>
    <message>
        <source>BitTorrent</source>
        <translation>BitTorrent</translation>
    </message>
    <message>
        <source>Web UI</source>
        <translation>Διεπαφή Χρήστη Ιστού</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Γλώσσα</translation>
    </message>
    <message>
        <source>User Interface Language:</source>
        <translation>Διεπαφή Χρήστη Γλώσσας:</translation>
    </message>
    <message>
        <source>Email notification upon download completion</source>
        <translation>Ειδοποίηση ηλεκτρονικού ταχυδρομείου με την ολοκλήρωση της λήψης</translation>
    </message>
    <message>
        <source>Run external program on torrent completion</source>
        <translation>Εκτέλεση εξωτερικού προγράμματος μετά την ολοκλήρωση ενός torrent</translation>
    </message>
    <message>
        <source>IP Filtering</source>
        <translation>Φιλτράρισμα IP</translation>
    </message>
    <message>
        <source>Schedule the use of alternative rate limits</source>
        <translation>Προγραμματισμός χρήσης εναλλακτικών ορίων ρυθμού</translation>
    </message>
    <message>
        <source>Torrent Queueing</source>
        <translation>Torrent στην Ουρά</translation>
    </message>
    <message>
        <source>Seed torrents until their seeding time reaches</source>
        <translation>Διαμοιρασμός των torrent μέχρι το χρονικό όριο</translation>
    </message>
    <message>
        <source>Automatically add these trackers to new downloads:</source>
        <translation>Αυτόματη προσθήκη αυτών των ιχνηλατών σε νέες λήψεις:</translation>
    </message>
    <message>
        <source>Web User Interface (Remote control)</source>
        <translation>Διαδικτυακό Περιβάλλον Χρήστη (Απομακρυσμένη διαχείριση)</translation>
    </message>
    <message>
        <source>IP address:</source>
        <translation>Διεύθυνση IP:</translation>
    </message>
    <message>
        <source>Server domains:</source>
        <translation>Τομείς διακομιστή:</translation>
    </message>
    <message>
        <source>Use HTTPS instead of HTTP</source>
        <translation>Χρήση HTTPS αντί για HTTP</translation>
    </message>
    <message>
        <source>Bypass authentication for clients on localhost</source>
        <translation>Παράκαμψη πιστοποίησης για υπολογιστές-πελάτες σε localhost</translation>
    </message>
    <message>
        <source>Bypass authentication for clients in whitelisted IP subnets</source>
        <translation>Παράκαμψη πιστοποίησης για υπολογιστές-πελάτες σε υποδίκτυα στη λίστα επιτρεπόμενων IP</translation>
    </message>
    <message>
        <source>Update my dynamic domain name</source>
        <translation>Ενημέρωση του δυναμικού ονόματος τομέα μου</translation>
    </message>
    <message>
        <source>Keep incomplete torrents in:</source>
        <translation>Διατήρηση μη ολοκληρωμένων torrent στο:</translation>
    </message>
    <message>
        <source>Copy .torrent files to:</source>
        <translation>Αντιγραφή αρχείων .torrent στο:</translation>
    </message>
    <message>
        <source>Copy .torrent files for finished downloads to:</source>
        <translation>Αντιγραφή αρχείων .torrent για ολοκληρωμένες λήψεις στο:</translation>
    </message>
    <message>
        <source>Pre-allocate disk space for all files</source>
        <translation>Προ-εντοπισμός χώρου στο δίσκο για όλα τα αρχεία</translation>
    </message>
    <message>
        <source>Append .!qB extension to incomplete files</source>
        <translation>Προσάρτηση επέκτασης .!qB σε μη ολοκληρωμένα αρχεία</translation>
    </message>
    <message>
        <source>Automatically add torrents from:</source>
        <translation>Αυτόματη προσθήκη torrent από:</translation>
    </message>
    <message>
        <source>SMTP server:</source>
        <translation>Διακομιστής SMTP:</translation>
    </message>
    <message>
        <source>This server requires a secure connection (SSL)</source>
        <translation>Αυτός ο διακομιστής απαιτεί ασφαλή σύνδεση (SSL)</translation>
    </message>
    <message>
        <source>Authentication</source>
        <translation>Έλεγχος Ταυτότητας</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Όνομα χρήστη:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Κωδικός:</translation>
    </message>
    <message>
        <source>Enabled protocol:</source>
        <translation>Ενεργό πρωτόκολλο</translation>
    </message>
    <message>
        <source>TCP and μTP</source>
        <translation>TCP και μTP</translation>
    </message>
    <message>
        <source>Listening Port</source>
        <translation>Θύρα ακρόασης</translation>
    </message>
    <message>
        <source>Port used for incoming connections:</source>
        <translation>Θύρα που χρησιμοποιείται για εισερχόμενες συνδέσεις:</translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation>Χρήση προώθησης UPnP / NAT - PMP θυρών από τον δρομολογητή μου</translation>
    </message>
    <message>
        <source>Use different port on each startup</source>
        <translation>Χρήση διαφορετικής θύρας σε κάθε εκκίνηση</translation>
    </message>
    <message>
        <source>Connections Limits</source>
        <translation>Όρια Συνδέσεων</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent:</source>
        <translation>Μέγιστος αριθμός συνδέσεων ανά torrent</translation>
    </message>
    <message>
        <source>Global maximum number of connections:</source>
        <translation>Μέγιστος συνολικός αριθμός συνδέσεων:</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Μέγιστος αριθμός θέσεων αποστολής ανά torrent:</translation>
    </message>
    <message>
        <source>Global maximum number of upload slots:</source>
        <translation>Γενικός μέγιστος αριθμός θέσεων αποστολής:</translation>
    </message>
    <message>
        <source>Proxy Server</source>
        <translation>Διακομιστής Μεσολάβησης</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Τύπος:</translation>
    </message>
    <message>
        <source>(None)</source>
        <translation>(Κανένα)</translation>
    </message>
    <message>
        <source>SOCKS4</source>
        <translation>SOCKS4</translation>
    </message>
    <message>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <source>Host:</source>
        <translation>Εξυπηρετητής:</translation>
    </message>
    <message>
        <source>Port:</source>
        <translation>Θύρα:</translation>
    </message>
    <message>
        <source>Use proxy for peer connections</source>
        <translation>Χρήση μεσολαβητή για συνδέσεις ομότιμων</translation>
    </message>
    <message>
        <source>Disable connections not supported by proxies</source>
        <translation>Απενεργοποίηση συνδέσεων που δεν υποστηρίζονται από διακομιστές μεσολάβησης</translation>
    </message>
    <message>
        <source>Use proxy only for torrents</source>
        <translation>Χρήση μεσολαβητή μόνο για torrents</translation>
    </message>
    <message>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>Διαδρομή φίλτρου (.dat, .p2p, .p2b):</translation>
    </message>
    <message>
        <source>Manually banned IP addresses...</source>
        <translation>Χειροκίνητα αποκλεισμένες IP διευθύνσεις...</translation>
    </message>
    <message>
        <source>Apply to trackers</source>
        <translation>Εφαρμογή στους ιχνηλάτες</translation>
    </message>
    <message>
        <source>Global Rate Limits</source>
        <translation>Γενικά Όρια Ρυθμού</translation>
    </message>
    <message>
        <source>Upload:</source>
        <translation>Αποστολή:</translation>
    </message>
    <message>
        <source>Download:</source>
        <translation>Λήψη</translation>
    </message>
    <message>
        <source>Alternative Rate Limits</source>
        <translation>Εναλλακτικά Όρια Ρυθμού</translation>
    </message>
    <message>
        <source>From:</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translation>Από:</translation>
    </message>
    <message>
        <source>To:</source>
        <extracomment>time1 to time2</extracomment>
        <translation>Προς:</translation>
    </message>
    <message>
        <source>When:</source>
        <translation>Πότε:</translation>
    </message>
    <message>
        <source>Every day</source>
        <translation>Κάθε μέρα</translation>
    </message>
    <message>
        <source>Weekdays</source>
        <translation>Καθημερινές</translation>
    </message>
    <message>
        <source>Weekends</source>
        <translation>Σαββατοκύριακα</translation>
    </message>
    <message>
        <source>Rate Limits Settings</source>
        <translation>Ρυθμίσεις Ορίων Ρυθμού</translation>
    </message>
    <message>
        <source>Apply rate limit to transport overhead</source>
        <translation>Εφαρμογή ορίων ρυθμού στο κόστος μεταφοράς</translation>
    </message>
    <message>
        <source>Apply rate limit to µTP protocol</source>
        <translation>Εφαρμογή ορίων ρυθμού στο uTP πρωτόκολλο</translation>
    </message>
    <message>
        <source>Privacy</source>
        <translation>Ιδιωτικότητα </translation>
    </message>
    <message>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation>Ενεργοποίηση DHT (αποκεντροποιημένο δίκτυο) για την εύρεση περισσοτέρων διασυνδέσεων</translation>
    </message>
    <message>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation>Ενεργοποίηση Ανταλλαγής Ομότιμων (PeX) για εύρεση περισσότερων ομότιμων χρηστών</translation>
    </message>
    <message>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation>Ενεργοποίηση Ανακάλυψης Τοπικών Διασυνδέσεων για την εύρεση περισσοτέρων διασυνδέσεων</translation>
    </message>
    <message>
        <source>Encryption mode:</source>
        <translation>Λειτουργία κρυπτογράφησης:</translation>
    </message>
    <message>
        <source>Prefer encryption</source>
        <translation>Προτίμηση κρυπτογράφησης</translation>
    </message>
    <message>
        <source>Require encryption</source>
        <translation>Απαίτηση κρυπτογράφησης</translation>
    </message>
    <message>
        <source>Disable encryption</source>
        <translation>Απενεργοποίηση κρυπτογράφησης</translation>
    </message>
    <message>
        <source>Enable anonymous mode</source>
        <translation>Ενεργοποίηση ανώνυμης λειτουργίας</translation>
    </message>
    <message>
        <source>Maximum active downloads:</source>
        <translation>Μέγιστες ενεργές λήψεις:</translation>
    </message>
    <message>
        <source>Maximum active uploads:</source>
        <translation>Μέγιστες ενεργές αποστολές:</translation>
    </message>
    <message>
        <source>Maximum active torrents:</source>
        <translation>Μέγιστα ενεργά torrents:</translation>
    </message>
    <message>
        <source>Do not count slow torrents in these limits</source>
        <translation>Μη υπολογισμός αργών torrent σε αυτά τα όρια</translation>
    </message>
    <message>
        <source>Share Ratio Limiting</source>
        <translation>Περιορισμός Αναλογίας Διαμοιρασμού</translation>
    </message>
    <message>
        <source>Seed torrents until their ratio reaches</source>
        <translation>Διαμοιρασμός των torrent μέχρι η αναλογία τους να φτάσει</translation>
    </message>
    <message>
        <source>then</source>
        <translation>τότε</translation>
    </message>
    <message>
        <source>Pause them</source>
        <translation>Παύση επιλεγμένων</translation>
    </message>
    <message>
        <source>Remove them</source>
        <translation>Αφαίρεση  επιλεγμένων</translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation>Χρήση UPnP / NAT - PMP για προώθηση της θύρας από τον δρομολογητή μου</translation>
    </message>
    <message>
        <source>Certificate:</source>
        <translation>Πιστοποιητικό:</translation>
    </message>
    <message>
        <source>Key:</source>
        <translation>Κλειδί:</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Εγγραφή</translation>
    </message>
    <message>
        <source>Domain name:</source>
        <translation>Όνομα τομέα:</translation>
    </message>
    <message>
        <source>Supported parameters (case sensitive):</source>
        <translation>Υποστηριζόμενοι παράμετροι (διάκριση πεζών):</translation>
    </message>
    <message>
        <source>%N: Torrent name</source>
        <translation>%N: Όνομα Torrent</translation>
    </message>
    <message>
        <source>%L: Category</source>
        <translation>%L: Κατηγορία</translation>
    </message>
    <message>
        <source>%F: Content path (same as root path for multifile torrent)</source>
        <translation>%F: Διαδρομή περιεχομένου (ίδια με την ριζική διαδρομή για torrent πολλαπλών αρχείων)</translation>
    </message>
    <message>
        <source>%R: Root path (first torrent subdirectory path)</source>
        <translation>%R: Ριζική διαδρομή (πρώτη διαδρομή υποκαταλόγου torrent)</translation>
    </message>
    <message>
        <source>%D: Save path</source>
        <translation>%D: Διαδρομή αποθήκευσης</translation>
    </message>
    <message>
        <source>%C: Number of files</source>
        <translation>%C: Αριθμός των αρχείων</translation>
    </message>
    <message>
        <source>%Z: Torrent size (bytes)</source>
        <translation>%Z: Μέγεθος torrent (bytes)</translation>
    </message>
    <message>
        <source>%T: Current tracker</source>
        <translation>%T: Τρέχων ιχνηλάτης</translation>
    </message>
    <message>
        <source>%I: Info hash</source>
        <translation>%I: Πληροφορίες hash</translation>
    </message>
    <message>
        <source>Tip: Encapsulate parameter with quotation marks to avoid text being cut off at whitespace (e.g., "%N")</source>
        <translation>Συμβουλή: Ενθυλακώστε την παράμετρο με εισαγωγικά για να αποφύγετε την αποκοπή του κειμένου στον κενό χώρο (π.χ., "%Ν")</translation>
    </message>
    <message>
        <source>The Web UI username must be at least 3 characters long.</source>
        <translation>Το όνομα χρήστη του Περιβάλλοντος Χρήστη Ιστού πρέπει να έχει μήκος τουλάχιστον 3 χαρακτήρες.</translation>
    </message>
    <message>
        <source>The Web UI password must be at least 6 characters long.</source>
        <translation>Ο κωδικός πρόσβασης του Περιβάλλοντος Χρήστη Ιστού πρέπει να έχει μήκος τουλάχιστον 6 χαρακτήρες.</translation>
    </message>
    <message>
        <source>minutes</source>
        <translation>λεπτά</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Enable clickjacking protection</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Enable Cross-Site Request Forgery (CSRF) protection</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Delete .torrent files afterwards</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Download rate threshold:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Upload rate threshold:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Change current password</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Automatic</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Use alternative Web UI</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Default Save Path:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>The alternative Web UI files location cannot be blank.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Do not start the download automatically</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Switch torrent to Manual Mode</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>When Torrent Category changed:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Relocate affected torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Apply rate limit to peers on LAN</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>0 means unlimited</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Relocate torrent</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>When Default Save Path changed:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Enable Host header validation</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Security</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>When Category Save Path changed:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Create subfolder for torrents with multiple files</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>seconds</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Switch affected torrents to Manual Mode</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Files location:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Manual</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Torrent inactivity timer:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Default Torrent Management Mode:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>When adding a torrent</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%G: Tags (separated by comma)</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <source>Port</source>
        <translation>Θύρα</translation>
    </message>
    <message>
        <source>Flags</source>
        <translation>Σημάνσεις</translation>
    </message>
    <message>
        <source>Connection</source>
        <translation>Σύνδεση</translation>
    </message>
    <message>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>Πελάτης</translation>
    </message>
    <message>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>Πρόοδος</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Ταχύτητα Λήψης</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Ταχύτητα Αποστολής</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>Ληφθέντα</translation>
    </message>
    <message>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>Απεσταλμένα</translation>
    </message>
    <message>
        <source>Relevance</source>
        <comment>i.e: How relevant this peer is to us. How many pieces it has that we don't.</comment>
        <translation>Συνάφεια</translation>
    </message>
    <message>
        <source>Files</source>
        <comment>i.e. files that are being downloaded right now</comment>
        <translation>Αρχεία</translation>
    </message>
    <message>
        <source>Country</source>
        <translation>Χώρα</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>Κανονική</translation>
    </message>
    <message>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>Υψηλή</translation>
    </message>
    <message>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>Μέγιστη</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <source>General</source>
        <translation>Γενικά</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation>Ιχνηλάτες</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation>Διασυνδέσεις</translation>
    </message>
    <message>
        <source>HTTP Sources</source>
        <translation>Πηγές HTTP</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>Περιεχόμενο</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <source>Downloaded:</source>
        <translation>Ληφθέντα:</translation>
    </message>
    <message>
        <source>Transfer</source>
        <translation>Μεταφορά</translation>
    </message>
    <message>
        <source>Time Active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>Χρόνος εν Ενεργεία:</translation>
    </message>
    <message>
        <source>ETA:</source>
        <translation>Εκτιμώμενος Χρόνος:</translation>
    </message>
    <message>
        <source>Uploaded:</source>
        <translation>Απεσταλμένα:</translation>
    </message>
    <message>
        <source>Seeds:</source>
        <translation>Διαμοιραστές:</translation>
    </message>
    <message>
        <source>Download Speed:</source>
        <translation>Ταχύτητα Λήψης:</translation>
    </message>
    <message>
        <source>Upload Speed:</source>
        <translation>Ταχύτητα Αποστολής:</translation>
    </message>
    <message>
        <source>Peers:</source>
        <translation>Διασυνδέσεις:</translation>
    </message>
    <message>
        <source>Download Limit:</source>
        <translation>Όριο Λήψης:</translation>
    </message>
    <message>
        <source>Upload Limit:</source>
        <translation>Όριο Αποστολής:</translation>
    </message>
    <message>
        <source>Wasted:</source>
        <translation>Χαμένα:</translation>
    </message>
    <message>
        <source>Connections:</source>
        <translation>Συνδέσεις:</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Πληροφορίες</translation>
    </message>
    <message>
        <source>Comment:</source>
        <translation>Σχόλιο:</translation>
    </message>
    <message>
        <source>Share Ratio:</source>
        <translation>Αναλογία Διαμοιρασμού:</translation>
    </message>
    <message>
        <source>Reannounce In:</source>
        <translation>Επανανακοίνωση Σε:</translation>
    </message>
    <message>
        <source>Last Seen Complete:</source>
        <translation>Τελευταία Φορά Ολοκλήρωσης:</translation>
    </message>
    <message>
        <source>Total Size:</source>
        <translation>Συνολικό Μέγεθος:</translation>
    </message>
    <message>
        <source>Pieces:</source>
        <translation>Κομμάτια:</translation>
    </message>
    <message>
        <source>Created By:</source>
        <translation>Δημιουργήθηκε Από:</translation>
    </message>
    <message>
        <source>Added On:</source>
        <translation>Προστέθηκε Στις:</translation>
    </message>
    <message>
        <source>Completed On:</source>
        <translation>Ολοκληρώθηκε Στις:</translation>
    </message>
    <message>
        <source>Created On:</source>
        <translation>Δημιουργήθηκε Στις:</translation>
    </message>
    <message>
        <source>Torrent Hash:</source>
        <translation>Torrent Hash:</translation>
    </message>
    <message>
        <source>Save Path:</source>
        <translation>Διαδρομή Αποθήκευσης:</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Ποτέ</translation>
    </message>
    <message>
        <source>%1 x %2 (have %3)</source>
        <comment>(torrent pieces) eg 152 x 4MB (have 25)</comment>
        <translation>%1 x %2 (έχω %3)</translation>
    </message>
    <message>
        <source>%1 (%2 this session)</source>
        <translation>%1 (%2 αυτή τη συνεδρία)</translation>
    </message>
    <message>
        <source>%1 (%2 max)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 max)</comment>
        <translation>%1 (%2 μέγιστο)</translation>
    </message>
    <message>
        <source>%1 (%2 total)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 total)</comment>
        <translation>%1 (%2 σύνολο)</translation>
    </message>
    <message>
        <source>%1 (%2 avg.)</source>
        <comment>%1 and %2 are speed rates, e.g. 200KiB/s (100KiB/s avg.)</comment>
        <translation>%1 (%2 μ.ο.)</translation>
    </message>
    <message>
        <source>Download limit:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Upload limit:</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <source>Monitored Folder</source>
        <translation>Φάκελος υπό Παρακολούθηση</translation>
    </message>
    <message>
        <source>Override Save Location</source>
        <translation>Παράκαμψη Τοποθεσίας Αποθήκευσης</translation>
    </message>
    <message>
        <source>Monitored folder</source>
        <translation>Φάκελος υπό παρακολούθηση</translation>
    </message>
    <message>
        <source>Default save location</source>
        <translation>Προεπιλεγμένη τοποθεσία αποθήκευσης</translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
    <message>
        <source>KiB/s</source>
        <translation>KiB/δ</translation>
    </message>
</context>
<context>
    <name>StatsDialog</name>
    <message>
        <source>Statistics</source>
        <translation>Στατιστικά</translation>
    </message>
    <message>
        <source>User statistics</source>
        <translation>Στατιστικά χρήστη</translation>
    </message>
    <message>
        <source>Cache statistics</source>
        <translation>Στατιστικά προσωρινής μνήμης</translation>
    </message>
    <message>
        <source>Read cache hits:</source>
        <translation>Συμβάντα ανάγνωσης προσωρινής μνήμης:</translation>
    </message>
    <message>
        <source>Average time in queue:</source>
        <translation>Μέσος χρόνος σε ουρά:</translation>
    </message>
    <message>
        <source>Connected peers:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>All-time share ratio:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>All-time download:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Session waste:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>All-time upload:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Total buffer size:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Performance statistics</source>
        <translation>Στατιστικά επιδόσεων</translation>
    </message>
    <message>
        <source>Queued I/O jobs:</source>
        <translation>Εργασίες Ι/Ο σε ουρά:</translation>
    </message>
    <message>
        <source>Write cache overload:</source>
        <translation>Υπερφόρτωση εγγραφής προσωρινής μνήμης:</translation>
    </message>
    <message>
        <source>Read cache overload:</source>
        <translation>Υπερφόρτωση ανάγνωσης προσωρινής μνήμης:</translation>
    </message>
    <message>
        <source>Total queued size:</source>
        <translation>Συνολικό μέγεθος σε ουρά:</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <source>DHT: %1 nodes</source>
        <translation>DHT: %1 κόμβοι</translation>
    </message>
</context>
<context>
    <name>StatusFilterWidget</name>
    <message>
        <source>All (0)</source>
        <comment>this is for the status filter</comment>
        <translation>Όλα (0)</translation>
    </message>
    <message>
        <source>Downloading (0)</source>
        <translation>Γίνεται Λήψη (0)</translation>
    </message>
    <message>
        <source>Seeding (0)</source>
        <translation>Γίνεται Διαμοιρασμός (0)</translation>
    </message>
    <message>
        <source>Completed (0)</source>
        <translation>Ολοκληρωμένα (0)</translation>
    </message>
    <message>
        <source>Resumed (0)</source>
        <translation>Σε Συνέχιση (0)</translation>
    </message>
    <message>
        <source>Paused (0)</source>
        <translation>Σε Παύση (0)</translation>
    </message>
    <message>
        <source>Active (0)</source>
        <translation>Ενεργά (0)</translation>
    </message>
    <message>
        <source>Inactive (0)</source>
        <translation>Ανενεργά (0)</translation>
    </message>
    <message>
        <source>Errored (0)</source>
        <translation>Με Σφάλμα (0)</translation>
    </message>
    <message>
        <source>All (%1)</source>
        <translation>Όλα (%1)</translation>
    </message>
    <message>
        <source>Downloading (%1)</source>
        <translation>Γίνεται Λήψη (%1)</translation>
    </message>
    <message>
        <source>Seeding (%1)</source>
        <translation>Γίνεται Διαμοιρασμός (%1)</translation>
    </message>
    <message>
        <source>Completed (%1)</source>
        <translation>Ολοκληρωμένα (%1)</translation>
    </message>
    <message>
        <source>Paused (%1)</source>
        <translation>Σε Παύση (%1)</translation>
    </message>
    <message>
        <source>Resumed (%1)</source>
        <translation>Σε Συνέχιση (%1)</translation>
    </message>
    <message>
        <source>Active (%1)</source>
        <translation>Ενεργά (%1)</translation>
    </message>
    <message>
        <source>Inactive (%1)</source>
        <translation>Ανενεργά (%1)</translation>
    </message>
    <message>
        <source>Errored (%1)</source>
        <translation>Με Σφάλμα (%1)</translation>
    </message>
</context>
<context>
    <name>TorrentContentModel</name>
    <message>
        <source>Name</source>
        <translation>Όνομα</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Μέγεθος</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Πρόοδος</translation>
    </message>
    <message>
        <source>Download Priority</source>
        <translation>Προτεραιότητα Λήψης</translation>
    </message>
    <message>
        <source>Remaining</source>
        <translation>Απομένουν</translation>
    </message>
    <message>
        <source>Availability</source>
        <translation>Διαθεσιμότητα</translation>
    </message>
</context>
<context>
    <name>TransferListModel</name>
    <message>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation>Όνομα</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation>Μέγεθος</translation>
    </message>
    <message>
        <source>Done</source>
        <comment>% Done</comment>
        <translation>Ολοκληρώθηκε</translation>
    </message>
    <message>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation>Κατάσταση</translation>
    </message>
    <message>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation>Διαμοιραστές</translation>
    </message>
    <message>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation>Αποδέκτες</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Ταχύτητα Λήψης</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Ταχύτητα Αποστολής</translation>
    </message>
    <message>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation>Αναλογία</translation>
    </message>
    <message>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation>ΕΤΑ</translation>
    </message>
    <message>
        <source>Category</source>
        <translation>Κατηγορία</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>Ετικέτες</translation>
    </message>
    <message>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation>Προστέθηκε στις</translation>
    </message>
    <message>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation>Ολοκληρώθηκε στις</translation>
    </message>
    <message>
        <source>Tracker</source>
        <translation>Ιχνηλάτης</translation>
    </message>
    <message>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation>Όριο Λήψης</translation>
    </message>
    <message>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation>Όριο Αποστολής</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation>Ληφθέντα</translation>
    </message>
    <message>
        <source>Uploaded</source>
        <comment>Amount of data uploaded (e.g. in MB)</comment>
        <translation>Απεσταλμένα</translation>
    </message>
    <message>
        <source>Session Download</source>
        <comment>Amount of data downloaded since program open (e.g. in MB)</comment>
        <translation>Λήψεις Συνεδρίας</translation>
    </message>
    <message>
        <source>Session Upload</source>
        <comment>Amount of data uploaded since program open (e.g. in MB)</comment>
        <translation>Αποστολές Συνεδρίας</translation>
    </message>
    <message>
        <source>Remaining</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation>Απομένουν</translation>
    </message>
    <message>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation>Χρόνος εν Ενεργεία</translation>
    </message>
    <message>
        <source>Save path</source>
        <comment>Torrent save path</comment>
        <translation>Διαδρομή αποθήκευσης</translation>
    </message>
    <message>
        <source>Completed</source>
        <comment>Amount of data completed (e.g. in MB)</comment>
        <translation>Ολοκληρωμένα</translation>
    </message>
    <message>
        <source>Ratio Limit</source>
        <comment>Upload share ratio limit</comment>
        <translation>Όριο Αναλογίας</translation>
    </message>
    <message>
        <source>Last Seen Complete</source>
        <comment>Indicates the time when the torrent was last seen complete/whole</comment>
        <translation>Τελευταία Φορά Ολοκλήρωσης</translation>
    </message>
    <message>
        <source>Last Activity</source>
        <comment>Time passed since a chunk was downloaded/uploaded</comment>
        <translation>Τελευταία Δραστηριότητα</translation>
    </message>
    <message>
        <source>Total Size</source>
        <comment>i.e. Size including unwanted data</comment>
        <translation>Συνολικό Μέγεθος</translation>
    </message>
</context>
<context>
    <name>TrackerListWidget</name>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Κατάσταση</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation>Αποδέκτες</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Μήνυμα</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Tracker URL:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Updating...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Working</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Disabled</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Not contacted yet</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>#</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>N/A</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Seeds</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Not working</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Copy tracker URL</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add a new tracker...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Edit tracker URL...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Tracker editing</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Leeches</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Remove tracker</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>TrackersAdditionDialog</name>
    <message>
        <source>Trackers addition dialog</source>
        <translation>Παράθυρο διαλόγου προσθήκης ιχνηλατών</translation>
    </message>
    <message>
        <source>List of trackers to add (one per line):</source>
        <translation>Λίστα ιχνηλατών προς προσθήκη (ένας ανά σειρά):</translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <source>%1 ago</source>
        <comment>e.g.: 1h 20m ago</comment>
        <translation>%1 πριν</translation>
    </message>
    <message>
        <source>Allocating</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Paused</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Completed</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Moving</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>[F] Seeding</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Seeding</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Queued</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Errored</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>[F] Downloading</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Downloading metadata</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Checking</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Missing Files</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Queued for checking</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Downloading</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Checking resume data</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Stalled</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <source>Status</source>
        <translation>Κατάσταση</translation>
    </message>
    <message>
        <source>Categories</source>
        <translation>Κατηγορίες</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <source>Torrent Download Speed Limiting</source>
        <translation>Περιορισμός Ταχύτητας Λήψης torrent</translation>
    </message>
    <message>
        <source>Torrent Upload Speed Limiting</source>
        <translation>Περιορισμός Ταχύτητας Αποστολής torrent</translation>
    </message>
    <message>
        <source>Rename</source>
        <translation>Μετονομασία</translation>
    </message>
    <message>
        <source>Resume</source>
        <comment>Resume/start the torrent</comment>
        <translation>Συνέχιση</translation>
    </message>
    <message>
        <source>Force Resume</source>
        <comment>Force Resume/start the torrent</comment>
        <translation>Εξαναγκαστική Συνέχιση</translation>
    </message>
    <message>
        <source>Pause</source>
        <comment>Pause the torrent</comment>
        <translation>Παύση</translation>
    </message>
    <message>
        <source>Delete</source>
        <comment>Delete the torrent</comment>
        <translation>Διαγραφή</translation>
    </message>
    <message>
        <source>Limit share ratio...</source>
        <translation>Περιορισμός αναλογίας διαμοιρασμού…</translation>
    </message>
    <message>
        <source>Limit upload rate...</source>
        <translation>Περιορισμός αναλογίας αποστολής…</translation>
    </message>
    <message>
        <source>Limit download rate...</source>
        <translation>Περιορισμός αναλογίας λήψης…</translation>
    </message>
    <message>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>Μετακίνηση επάνω</translation>
    </message>
    <message>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>Μετακίνηση κάτω</translation>
    </message>
    <message>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>Μετακίνηση στην κορυφή</translation>
    </message>
    <message>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>Μετακίνηση στο τέλος</translation>
    </message>
    <message>
        <source>Set location...</source>
        <translation>Ρύθμιση τοποθεσίας…</translation>
    </message>
    <message>
        <source>Copy name</source>
        <translation>Αντιγραφή ονόματος</translation>
    </message>
    <message>
        <source>Copy hash</source>
        <translation>Αντιγραφή hash</translation>
    </message>
    <message>
        <source>Download first and last pieces first</source>
        <translation>Λήψη πρώτων και τελευταίων κομματιών πρώτα</translation>
    </message>
    <message>
        <source>Automatic Torrent Management</source>
        <translation>Αυτόματη Διαχείριση Torrent</translation>
    </message>
    <message>
        <source>Category</source>
        <translation>Κατηγορία</translation>
    </message>
    <message>
        <source>New...</source>
        <comment>New category...</comment>
        <translation>Νέα...</translation>
    </message>
    <message>
        <source>Reset</source>
        <comment>Reset category</comment>
        <translation>Επαναφορά</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Προτεραιότητα</translation>
    </message>
    <message>
        <source>Force recheck</source>
        <translation>Εξαναγκαστικός επανέλεγχος</translation>
    </message>
    <message>
        <source>Copy magnet link</source>
        <translation>Αντιγραφή συνδέσμου magnet</translation>
    </message>
    <message>
        <source>Super seeding mode</source>
        <translation>Λειτουργία ενισχυμένου διαμοιρασμού</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Μετονομασία…</translation>
    </message>
    <message>
        <source>Download in sequential order</source>
        <translation>Λήψη σε διαδοχική σειρά</translation>
    </message>
    <message>
        <source>Force Recheck</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>New Category</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Location</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>New name</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Set location</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Force reannounce</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Edit Category</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Save path</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>UpDownRatioDialog</name>
    <message>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation>Περιορισμός αναλογίας Αποστολής/Λήψης torrent</translation>
    </message>
    <message>
        <source>Use global share limit</source>
        <translation>Χρήση γενικού ορίου αναλογίας</translation>
    </message>
    <message>
        <source>Set no share limit</source>
        <translation>Χωρίς όριο αναλογίας</translation>
    </message>
    <message>
        <source>Set share limit to</source>
        <translation>Ρύθμιση ορίου αναλογίας σε</translation>
    </message>
    <message>
        <source>ratio</source>
        <translation>αναλογία</translation>
    </message>
    <message>
        <source>minutes</source>
        <translation>λεπτά</translation>
    </message>
</context>
<context>
    <name>about</name>
    <message>
        <source>An advanced BitTorrent client programmed in C++, based on Qt toolkit and libtorrent-rasterbar.</source>
        <translation>Ένας προηγμένος BitTorrent πελάτης προγραμματισμένος σε C++, βασισμένος στην εργαλειοθήκη Qt και στο libtorrent-rasterbar.</translation>
    </message>
    <message>
        <source>Home Page:</source>
        <translation>Αρχική Σελίδα:</translation>
    </message>
    <message>
        <source>Forum:</source>
        <translation>Φόρουμ:</translation>
    </message>
    <message>
        <source>Bug Tracker:</source>
        <translation>Ιχνηλάτης Σφαλμάτων:</translation>
    </message>
</context>
<context>
    <name>confirmDeletionDlg</name>
    <message>
        <source>Deletion confirmation</source>
        <translation>Επιβεβαίωση διαγραφής</translation>
    </message>
    <message>
        <source>Also delete the files on the hard disk</source>
        <translation>Να διαγραφούν επίσης τα αρχεία στο σκληρό δίσκο</translation>
    </message>
    <message>
        <source>Deletion confirmation - qBittorrent</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>downloadFromURL</name>
    <message>
        <source>Download from URLs</source>
        <translation>Λήψη από διευθύνσεις URL</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Λήψη</translation>
    </message>
    <message>
        <source>Add Torrent Links</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <source>B</source>
        <comment>bytes</comment>
        <translation>B</translation>
    </message>
    <message>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>KiB</translation>
    </message>
    <message>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>MiB</translation>
    </message>
    <message>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>GiB</translation>
    </message>
    <message>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>TiB</translation>
    </message>
    <message>
        <source>PiB</source>
        <comment>pebibytes (1024 tebibytes)</comment>
        <translation>PiB</translation>
    </message>
    <message>
        <source>EiB</source>
        <comment>exbibytes (1024 pebibytes)</comment>
        <translation>EiB</translation>
    </message>
    <message>
        <source>/s</source>
        <comment>per second</comment>
        <translation>/δ</translation>
    </message>
    <message>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation>%1ώ %2λ</translation>
    </message>
    <message>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation>%1μ %2ώ</translation>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>Άγνωστο</translation>
    </message>
    <message>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt; 1λ</translation>
    </message>
    <message>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1λ</translation>
    </message>
</context>
<context>
    <name>TorrentsController</name>
    <message>
        <source>Save path is empty</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>PluginSourceDlg</name>
    <message>
        <source>Cancel</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Plugin path:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>URL or local directory</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Install plugin</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Ok</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>SearchEngineWidget</name>
    <message>
        <source>Seeds:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>All plugins</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Size:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Stop</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Search</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Search plugins...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>All categories</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Search in:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Copy description page URL</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Go to description page</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Results (showing</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Download</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Filter</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Torrent names only</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Only enabled</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>out of</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Everywhere</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>PluginSelectDlg</name>
    <message>
        <source>Uninstall</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Install new plugin</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>You can get new search engine plugins here:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Installed search plugins:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Enabled</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Warning: Be sure to comply with your country's copyright laws when downloading torrents from any of these search engines.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Check for updates</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Search plugins</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>SearchResultsTable</name>
    <message>
        <source>Name</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Size</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Leechers</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Search engine</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Seeders</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>SearchPluginsTable</name>
    <message>
        <source>Name</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Url</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Enabled</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Version</source>
        <translation type="unfinished" />
    </message>
</context>
</TS>