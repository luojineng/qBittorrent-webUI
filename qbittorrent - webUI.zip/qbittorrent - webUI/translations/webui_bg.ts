<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS language="bg" version="2.1">
<context>
    <name>AboutDlg</name>
    <message>
        <source>About</source>
        <translation>Относно</translation>
    </message>
</context>
<context>
    <name>AddNewTorrentDialog</name>
    <message>
        <source>Category:</source>
        <translation>Категория:</translation>
    </message>
    <message>
        <source>Start torrent</source>
        <translation>Стартирай торента</translation>
    </message>
    <message>
        <source>Skip hash check</source>
        <translation>Прескочи проверката на парчетата</translation>
    </message>
    <message>
        <source>Create subfolder</source>
        <translation>Създаване на поддиректория</translation>
    </message>
    <message>
        <source>Torrent Management Mode:</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>CategoryFilterModel</name>
    <message>
        <source>All</source>
        <translation>Всички</translation>
    </message>
    <message>
        <source>Uncategorized</source>
        <translation>Некатегоризирани</translation>
    </message>
</context>
<context>
    <name>CategoryFilterWidget</name>
    <message>
        <source>Add category...</source>
        <translation>Добавяне категория...</translation>
    </message>
    <message>
        <source>Remove category</source>
        <translation>Премахване категория</translation>
    </message>
    <message>
        <source>Remove unused categories</source>
        <translation>Изтриване на неизползваните категории</translation>
    </message>
    <message>
        <source>Resume torrents</source>
        <translation>Продължаване на торентите</translation>
    </message>
    <message>
        <source>Pause torrents</source>
        <translation>Пауза на торентите</translation>
    </message>
    <message>
        <source>Delete torrents</source>
        <translation>Изтриване на торентите</translation>
    </message>
    <message>
        <source>New Category</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Edit category...</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <source>Exit qBittorrent</source>
        <translation>Изход от qBittorrent</translation>
    </message>
    <message>
        <source>Only one link per line</source>
        <translation>Само един линк на реда</translation>
    </message>
    <message>
        <source>Global upload rate limit must be greater than 0 or disabled.</source>
        <translation>Глобалното ограничение за скорост на качване трябва да е по-голямо от 0 или изключено.</translation>
    </message>
    <message>
        <source>Global download rate limit must be greater than 0 or disabled.</source>
        <translation>Глобалното ограничение за скорост на сваляне трябва да е по-голямо от 0 или изключено.</translation>
    </message>
    <message>
        <source>Alternative upload rate limit must be greater than 0 or disabled.</source>
        <translation>Алтернативното ограничение за скорост на качване трябва да е по-голямо от 0 или изключено.</translation>
    </message>
    <message>
        <source>Alternative download rate limit must be greater than 0 or disabled.</source>
        <translation>Алтернативното ограничение за скорост на сваляне трябва да е по-голямо от 0 или изключено.</translation>
    </message>
    <message>
        <source>Maximum active downloads must be greater than -1.</source>
        <translation>Максимумът за активни сваляния трябва да бъде по-голям от -1.</translation>
    </message>
    <message>
        <source>Maximum active uploads must be greater than -1.</source>
        <translation>Максимумът за активни качвания трябва да бъде по-голям от -1.</translation>
    </message>
    <message>
        <source>Maximum active torrents must be greater than -1.</source>
        <translation>Максимумът за активни торенти трябва да бъде по-голям от -1.</translation>
    </message>
    <message>
        <source>Maximum number of connections limit must be greater than 0 or disabled.</source>
        <translation>Ограничението за максимален брой връзки трябва да е по-голямо от 0 или изключено.</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent limit must be greater than 0 or disabled.</source>
        <translation>Ограничението за максимален брой връзки на торент трябва да е по-голямо от 0 или изключено.</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</source>
        <translation>Ограничението за максимален брой слотове на торент трябва да е по-голямо от 0 или изключено.</translation>
    </message>
    <message>
        <source>Unable to save program preferences, qBittorrent is probably unreachable.</source>
        <translation>Не мога да съхраня предпочитанията за програмата, qBittorrent е вероятно недостъпен.</translation>
    </message>
    <message>
        <source>IRC: #qbittorrent on Freenode</source>
        <translation>IRC: #qbittorrent на Freenode</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Неизвестен</translation>
    </message>
    <message>
        <source>Share ratio limit must be between 0 and 9998.</source>
        <translation>Ограничението на съотношението на споделяне трябва да бъде между 0 и 9998.</translation>
    </message>
    <message>
        <source>Seeding time limit must be between 0 and 525600 minutes.</source>
        <translation>Ограничението за време на споделяне трябва да бъде между 0 и 525600 минути.</translation>
    </message>
    <message>
        <source>The port used for incoming connections must be between 1 and 65535.</source>
        <translation>Портът, който се използва за входящи връзки трябва да бъде между 1 и 65535.</translation>
    </message>
    <message>
        <source>The port used for the Web UI must be between 1 and 65535.</source>
        <translation>Портът, който се използва за Web UI трябва да бъде между 1 и 65535.</translation>
    </message>
    <message>
        <source>Unable to log in, qBittorrent is probably unreachable.</source>
        <translation>Невъзможност за логване, qBittorrent вероятно е недостъпен.</translation>
    </message>
    <message>
        <source>Invalid Username or Password.</source>
        <translation>Невалидно потребителско име или парола.</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Потребителско име</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Парола</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Вход</translation>
    </message>
    <message>
        <source>Original authors</source>
        <translation>Оригинален автори</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Прилагане</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Добавяне</translation>
    </message>
    <message>
        <source>Upload Torrents</source>
        <comment>Upload torrent files to qBittorent using WebUI</comment>
        <translation>Качване на Торенти</translation>
    </message>
    <message>
        <source>Save files to location:</source>
        <translation>Съхрани файловете на място:</translation>
    </message>
    <message>
        <source>Cookie:</source>
        <translation>Бисквитка:</translation>
    </message>
    <message>
        <source>Type folder here</source>
        <translation>Напишете директория тук</translation>
    </message>
    <message>
        <source>More information</source>
        <translation>Повече информация</translation>
    </message>
    <message>
        <source>Information about certificates</source>
        <translation>Информация за сертификатите</translation>
    </message>
    <message>
        <source>Set location</source>
        <translation>Задаване на местоположение</translation>
    </message>
    <message>
        <source>Limit upload rate</source>
        <translation>Ограничение на процента качване</translation>
    </message>
    <message>
        <source>Limit download rate</source>
        <translation>Ограничение на процента на сваляне</translation>
    </message>
    <message>
        <source>Rename torrent</source>
        <translation>Преименуване на торент</translation>
    </message>
    <message>
        <source>Other...</source>
        <comment>Save Files to: Watch Folder / Default Folder / Other...</comment>
        <translation>Други...</translation>
    </message>
    <message>
        <source>Monday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Понеделник</translation>
    </message>
    <message>
        <source>Tuesday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Вторник</translation>
    </message>
    <message>
        <source>Wednesday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Сряда</translation>
    </message>
    <message>
        <source>Thursday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Четвъртък</translation>
    </message>
    <message>
        <source>Friday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Петък</translation>
    </message>
    <message>
        <source>Saturday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Събота</translation>
    </message>
    <message>
        <source>Sunday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Неделя</translation>
    </message>
    <message>
        <source>Logout</source>
        <translation>Излизане</translation>
    </message>
    <message>
        <source>Download Torrents from their URLs or Magnet links</source>
        <translation>Сваляне на Торенти от техните URL-ове или Magnet линкове</translation>
    </message>
    <message>
        <source>Upload local torrent</source>
        <translation>Качване на локален торент</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the selected torrents from the transfer list?</source>
        <translation>Сигурни ли сте, че искате да изтриете избраните торенти от списъка за трансфер?</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Съхрани</translation>
    </message>
    <message>
        <source>qBittorrent client is not reachable</source>
        <translation>qBittorrent клиента е недостъпен</translation>
    </message>
    <message>
        <source>Global number of upload slots limit must be greater than 0 or disabled.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Invalid category name:\nPlease do not use any special characters in the category name.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Unable to create category</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Upload rate threshold must be greater than 0.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Free space: %1</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Torrent inactivity timer must be greater than 0.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Saving Management</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Download rate threshold must be greater than 0.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>qBittorrent has been shutdown</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>JavaScript Required! You must enable JavaScript for the Web UI to work properly</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation>Инструменти</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Файл</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Помощ</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Оглед</translation>
    </message>
    <message>
        <source>Options...</source>
        <translation>Опции...</translation>
    </message>
    <message>
        <source>Resume</source>
        <translation>Пауза</translation>
    </message>
    <message>
        <source>Minimum Priority</source>
        <translation>Минимален Приоритет</translation>
    </message>
    <message>
        <source>Top Priority</source>
        <translation>Най-висок Приоритет</translation>
    </message>
    <message>
        <source>Decrease Priority</source>
        <translation>Намаляване на Приоритета</translation>
    </message>
    <message>
        <source>Increase Priority</source>
        <translation>Увеличаване на Приоритета</translation>
    </message>
    <message>
        <source>Top Toolbar</source>
        <translation>Горна Лента с Инструменти</translation>
    </message>
    <message>
        <source>Status Bar</source>
        <translation>Статус Лента</translation>
    </message>
    <message>
        <source>Speed in Title Bar</source>
        <translation>Скорост в Заглавната Лента</translation>
    </message>
    <message>
        <source>Donate!</source>
        <translation>Дари!</translation>
    </message>
    <message>
        <source>Resume All</source>
        <translation>Пауза Всички</translation>
    </message>
    <message>
        <source>Statistics</source>
        <translation>Статистики</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Относно</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation>Пауза</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Изтрий</translation>
    </message>
    <message>
        <source>Pause All</source>
        <translation>Пауза Всички</translation>
    </message>
    <message>
        <source>Add Torrent File...</source>
        <translation>Добавяне Торент Файл...</translation>
    </message>
    <message>
        <source>Documentation</source>
        <translation>Документация</translation>
    </message>
    <message>
        <source>Add Torrent Link...</source>
        <translation>Добавяне Линк на Торент</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Да</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Не</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation>Общ лимит Скорост на качване</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation>Общ лимит Скорост на сваляне</translation>
    </message>
    <message>
        <source>Are you sure you want to quit qBittorrent?</source>
        <translation>Сигурни ли сте, че искате на излезете от qBittorent?</translation>
    </message>
    <message>
        <source>[D: %1, U: %2] qBittorrent %3</source>
        <comment>D = Download; U = Upload; %3 is qBittorrent version</comment>
        <translation>[С: %1, К: %2] qBittorrent %3</translation>
    </message>
    <message>
        <source>Alternative speed limits</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Search Engine</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Filter torrent list...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Search</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Transfers</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Настройки</translation>
    </message>
    <message>
        <source>Downloads</source>
        <translation>Сваляния</translation>
    </message>
    <message>
        <source>Connection</source>
        <translation>Връзка</translation>
    </message>
    <message>
        <source>Speed</source>
        <translation>Скорост</translation>
    </message>
    <message>
        <source>BitTorrent</source>
        <translation>BitTorrent</translation>
    </message>
    <message>
        <source>Web UI</source>
        <translation>Уеб ПИ</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Език</translation>
    </message>
    <message>
        <source>User Interface Language:</source>
        <translation>Език на Потребителския Интерфейс:</translation>
    </message>
    <message>
        <source>Email notification upon download completion</source>
        <translation>Уведомяване с имейл при завършване на свалянето</translation>
    </message>
    <message>
        <source>Run external program on torrent completion</source>
        <translation>Изпълняване на външна програма при завършване на торент</translation>
    </message>
    <message>
        <source>IP Filtering</source>
        <translation>IP Филтриране</translation>
    </message>
    <message>
        <source>Schedule the use of alternative rate limits</source>
        <translation>График на използването на алтернативни пределни скорости</translation>
    </message>
    <message>
        <source>Torrent Queueing</source>
        <translation>Нареждане на Oпашка на Торенти</translation>
    </message>
    <message>
        <source>Seed torrents until their seeding time reaches</source>
        <translation>Споделяне на торентите, докато тяхното време на споделяне не достигне</translation>
    </message>
    <message>
        <source>Automatically add these trackers to new downloads:</source>
        <translation>Автоматично добавяне на тези тракери към нови сваляния:</translation>
    </message>
    <message>
        <source>Web User Interface (Remote control)</source>
        <translation>Потребителски Уеб Интерфейс (Отдалечен контрол)</translation>
    </message>
    <message>
        <source>IP address:</source>
        <translation>IP адрес:</translation>
    </message>
    <message>
        <source>Server domains:</source>
        <translation>Сървърни домейни:</translation>
    </message>
    <message>
        <source>Use HTTPS instead of HTTP</source>
        <translation>Използване на HTTPS вместо HTTP</translation>
    </message>
    <message>
        <source>Bypass authentication for clients on localhost</source>
        <translation>Заобиколи удостоверяването на клиенти от localhost</translation>
    </message>
    <message>
        <source>Bypass authentication for clients in whitelisted IP subnets</source>
        <translation>Заобиколи удостоверяването на клиенти от позволените IP подмрежи</translation>
    </message>
    <message>
        <source>Update my dynamic domain name</source>
        <translation>Обнови моето динамично име на домейн</translation>
    </message>
    <message>
        <source>Keep incomplete torrents in:</source>
        <translation>Запазване на незавършени торенти в:</translation>
    </message>
    <message>
        <source>Copy .torrent files to:</source>
        <translation>Копирай .торент файловете в:</translation>
    </message>
    <message>
        <source>Copy .torrent files for finished downloads to:</source>
        <translation>Копирай .torrent файловете от приключилите изтегляния в:</translation>
    </message>
    <message>
        <source>Pre-allocate disk space for all files</source>
        <translation>Преразпредели дисково пространство за всички файлове </translation>
    </message>
    <message>
        <source>Append .!qB extension to incomplete files</source>
        <translation>Добави .!qB разширение към незавършени файлове</translation>
    </message>
    <message>
        <source>Automatically add torrents from:</source>
        <translation>Автоматично добави торенти от:</translation>
    </message>
    <message>
        <source>SMTP server:</source>
        <translation>SMTP сървър:</translation>
    </message>
    <message>
        <source>This server requires a secure connection (SSL)</source>
        <translation>Този сървър изисква защитена връзка (SSL)</translation>
    </message>
    <message>
        <source>Authentication</source>
        <translation>Удостоверяване</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Име на потребителя:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Парола:</translation>
    </message>
    <message>
        <source>Enabled protocol:</source>
        <translation>Активиране на протокол:</translation>
    </message>
    <message>
        <source>TCP and μTP</source>
        <translation>TCP и μTP</translation>
    </message>
    <message>
        <source>Listening Port</source>
        <translation>Порт за слушане</translation>
    </message>
    <message>
        <source>Port used for incoming connections:</source>
        <translation>Порт ползван за входящи връзки:</translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation>Използване на UPnP / NAT-PMP порт за препращане от моя рутер</translation>
    </message>
    <message>
        <source>Use different port on each startup</source>
        <translation>Използване на различен порт при всяко стартиране</translation>
    </message>
    <message>
        <source>Connections Limits</source>
        <translation>Ограничения на Връзките</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent:</source>
        <translation>Максимален брой връзки на торент:</translation>
    </message>
    <message>
        <source>Global maximum number of connections:</source>
        <translation>Общ максимален брой на връзки:</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Максимален брой слотове за качване на торент:</translation>
    </message>
    <message>
        <source>Global maximum number of upload slots:</source>
        <translation>Глобален максимален брой слотове за качване:</translation>
    </message>
    <message>
        <source>Proxy Server</source>
        <translation>Прокси Сървър</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Тип:</translation>
    </message>
    <message>
        <source>(None)</source>
        <translation>(Без)</translation>
    </message>
    <message>
        <source>SOCKS4</source>
        <translation>SOCKS4</translation>
    </message>
    <message>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <source>Host:</source>
        <translation>Хост:</translation>
    </message>
    <message>
        <source>Port:</source>
        <translation>Порт:</translation>
    </message>
    <message>
        <source>Use proxy for peer connections</source>
        <translation>Използвайте прокси за свързване между участниците</translation>
    </message>
    <message>
        <source>Disable connections not supported by proxies</source>
        <translation>Деактивиране на връзките, които не се поддържат от проксита.</translation>
    </message>
    <message>
        <source>Use proxy only for torrents</source>
        <translation>Използване на прокси само за торентите</translation>
    </message>
    <message>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>Филтър път (.dat, .p2p, .p2b): </translation>
    </message>
    <message>
        <source>Manually banned IP addresses...</source>
        <translation>Ръчно блокирани IP адреси...</translation>
    </message>
    <message>
        <source>Apply to trackers</source>
        <translation>Прилагане към тракери</translation>
    </message>
    <message>
        <source>Global Rate Limits</source>
        <translation>Общи Пределни Скорости</translation>
    </message>
    <message>
        <source>Upload:</source>
        <translation>Качване:</translation>
    </message>
    <message>
        <source>Download:</source>
        <translation>Сваляне:</translation>
    </message>
    <message>
        <source>Alternative Rate Limits</source>
        <translation>Алтернативни Пределни Скорости</translation>
    </message>
    <message>
        <source>From:</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translation>От:</translation>
    </message>
    <message>
        <source>To:</source>
        <extracomment>time1 to time2</extracomment>
        <translation>До:</translation>
    </message>
    <message>
        <source>When:</source>
        <translation>Когато:</translation>
    </message>
    <message>
        <source>Every day</source>
        <translation>Всеки ден</translation>
    </message>
    <message>
        <source>Weekdays</source>
        <translation>Дни през седмицата</translation>
    </message>
    <message>
        <source>Weekends</source>
        <translation>Почивни дни</translation>
    </message>
    <message>
        <source>Rate Limits Settings</source>
        <translation>Настройки на Пределни Скорости </translation>
    </message>
    <message>
        <source>Apply rate limit to transport overhead</source>
        <translation>Прилагане на пределна скорост за пренатоварено пренасяне</translation>
    </message>
    <message>
        <source>Apply rate limit to µTP protocol</source>
        <translation>Прилагане на пределна скорост за µTP протокола</translation>
    </message>
    <message>
        <source>Privacy</source>
        <translation>Дискретност</translation>
    </message>
    <message>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation>Активиране на DHT (децентрализирана мрежа) за намиране на повече участници</translation>
    </message>
    <message>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation>Активиране на Обмяна на Участници (PeX) за намиране на повече участници</translation>
    </message>
    <message>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation>Включи Откриване на Локални Участници за намиране на повече връзки</translation>
    </message>
    <message>
        <source>Encryption mode:</source>
        <translation>Режим на кодиране:</translation>
    </message>
    <message>
        <source>Prefer encryption</source>
        <translation>Предпочитане на кодиране</translation>
    </message>
    <message>
        <source>Require encryption</source>
        <translation>Изискване на кодиране</translation>
    </message>
    <message>
        <source>Disable encryption</source>
        <translation>Изключване на кодиране</translation>
    </message>
    <message>
        <source>Enable anonymous mode</source>
        <translation>Включи анонимен режим</translation>
    </message>
    <message>
        <source>Maximum active downloads:</source>
        <translation>Максимум активни сваляния:</translation>
    </message>
    <message>
        <source>Maximum active uploads:</source>
        <translation>Максимум активни качвания:</translation>
    </message>
    <message>
        <source>Maximum active torrents:</source>
        <translation>Максимум активни торенти:</translation>
    </message>
    <message>
        <source>Do not count slow torrents in these limits</source>
        <translation>Не изчислявай бавни торенти в тези лимити</translation>
    </message>
    <message>
        <source>Share Ratio Limiting</source>
        <translation>Ограничаване Съотношението на Споделяне</translation>
    </message>
    <message>
        <source>Seed torrents until their ratio reaches</source>
        <translation>Споделяне на торенти, докато съотношението им достигне</translation>
    </message>
    <message>
        <source>then</source>
        <translation>тогава</translation>
    </message>
    <message>
        <source>Pause them</source>
        <translation>Сложи ги в пауза</translation>
    </message>
    <message>
        <source>Remove them</source>
        <translation>Изтрий ги</translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation>Изпозване на UPnP / NAT-PMP за препращане порта от моя рутер</translation>
    </message>
    <message>
        <source>Certificate:</source>
        <translation>Сертификат:</translation>
    </message>
    <message>
        <source>Key:</source>
        <translation>Ключ:</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Регистър</translation>
    </message>
    <message>
        <source>Domain name:</source>
        <translation>Домейн име:</translation>
    </message>
    <message>
        <source>Supported parameters (case sensitive):</source>
        <translation>Поддържани параметри (чувствителност към регистъра)</translation>
    </message>
    <message>
        <source>%N: Torrent name</source>
        <translation>%N: Име на торент</translation>
    </message>
    <message>
        <source>%L: Category</source>
        <translation>%L: Категория</translation>
    </message>
    <message>
        <source>%F: Content path (same as root path for multifile torrent)</source>
        <translation>%F: Местоположение на съдържанието (същото като местоположението на основната директория за торент с множество файлове)</translation>
    </message>
    <message>
        <source>%R: Root path (first torrent subdirectory path)</source>
        <translation>%R: Местоположение на основната директория (местоположението на първата поддиректория за торент)</translation>
    </message>
    <message>
        <source>%D: Save path</source>
        <translation>%D: Местоположение за запис</translation>
    </message>
    <message>
        <source>%C: Number of files</source>
        <translation>%C: Брой на файловете</translation>
    </message>
    <message>
        <source>%Z: Torrent size (bytes)</source>
        <translation>%Z: Размер на торента (байтове)</translation>
    </message>
    <message>
        <source>%T: Current tracker</source>
        <translation>%T: Сегашен тракер</translation>
    </message>
    <message>
        <source>%I: Info hash</source>
        <translation>%I: Информационен отпечатък</translation>
    </message>
    <message>
        <source>Tip: Encapsulate parameter with quotation marks to avoid text being cut off at whitespace (e.g., "%N")</source>
        <translation>Подсказка: Обградете параметър с кавички за предотвратяваме орязването на текста при пауза (пр., "%N")</translation>
    </message>
    <message>
        <source>The Web UI username must be at least 3 characters long.</source>
        <translation>Потребителското име на Web UI трябва да е поне от 3 символа.</translation>
    </message>
    <message>
        <source>The Web UI password must be at least 6 characters long.</source>
        <translation>Паролата на Web UI трябва да е поне от 6 символа.</translation>
    </message>
    <message>
        <source>minutes</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>KiB/s</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Enable clickjacking protection</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Enable Cross-Site Request Forgery (CSRF) protection</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Delete .torrent files afterwards</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Download rate threshold:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Upload rate threshold:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Change current password</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Automatic</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Use alternative Web UI</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Default Save Path:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>The alternative Web UI files location cannot be blank.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Do not start the download automatically</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Switch torrent to Manual Mode</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>When Torrent Category changed:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Relocate affected torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Apply rate limit to peers on LAN</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>0 means unlimited</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Relocate torrent</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>When Default Save Path changed:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Enable Host header validation</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Security</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>When Category Save Path changed:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Create subfolder for torrents with multiple files</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>seconds</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Switch affected torrents to Manual Mode</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Files location:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Manual</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Torrent inactivity timer:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Default Torrent Management Mode:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>When adding a torrent</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%G: Tags (separated by comma)</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <source>Port</source>
        <translation>Порт</translation>
    </message>
    <message>
        <source>Flags</source>
        <translation>Флагове</translation>
    </message>
    <message>
        <source>Connection</source>
        <translation>Връзка</translation>
    </message>
    <message>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>Клиент</translation>
    </message>
    <message>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>Изпълнение</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Скорост на сваляне</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Скорост на качване</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>Свалени</translation>
    </message>
    <message>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>Качени</translation>
    </message>
    <message>
        <source>Relevance</source>
        <comment>i.e: How relevant this peer is to us. How many pieces it has that we don't.</comment>
        <translation>Уместност</translation>
    </message>
    <message>
        <source>Files</source>
        <comment>i.e. files that are being downloaded right now</comment>
        <translation>Файлове</translation>
    </message>
    <message>
        <source>Country</source>
        <translation>Страна</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>Нормален</translation>
    </message>
    <message>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>Висок</translation>
    </message>
    <message>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>Максимален</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <source>General</source>
        <translation>Общи</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation>Тракери</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation>Участници</translation>
    </message>
    <message>
        <source>HTTP Sources</source>
        <translation>HTTP Източници</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>Съдържание</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <source>Downloaded:</source>
        <translation>Свалени:</translation>
    </message>
    <message>
        <source>Transfer</source>
        <translation>Трансфер</translation>
    </message>
    <message>
        <source>Time Active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>Време на активност:</translation>
    </message>
    <message>
        <source>ETA:</source>
        <translation>Оставащо време:</translation>
    </message>
    <message>
        <source>Uploaded:</source>
        <translation>Качени:</translation>
    </message>
    <message>
        <source>Seeds:</source>
        <translation>Споделящи:</translation>
    </message>
    <message>
        <source>Download Speed:</source>
        <translation>Скорост на Сваляне:</translation>
    </message>
    <message>
        <source>Upload Speed:</source>
        <translation>Скорост на Качване:</translation>
    </message>
    <message>
        <source>Peers:</source>
        <translation>Участници:</translation>
    </message>
    <message>
        <source>Download Limit:</source>
        <translation>Ограничение на Сваляне:</translation>
    </message>
    <message>
        <source>Upload Limit:</source>
        <translation>Ограничение на Качване:</translation>
    </message>
    <message>
        <source>Wasted:</source>
        <translation>Изгубени:</translation>
    </message>
    <message>
        <source>Connections:</source>
        <translation>Връзки:</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Информация</translation>
    </message>
    <message>
        <source>Comment:</source>
        <translation>Коментар:</translation>
    </message>
    <message>
        <source>Share Ratio:</source>
        <translation>Съотношение на Споделяне:</translation>
    </message>
    <message>
        <source>Reannounce In:</source>
        <translation>Повторно анонсиране В:</translation>
    </message>
    <message>
        <source>Last Seen Complete:</source>
        <translation>Последно Видян Приключен:</translation>
    </message>
    <message>
        <source>Total Size:</source>
        <translation>Общ Размер:</translation>
    </message>
    <message>
        <source>Pieces:</source>
        <translation>Части:</translation>
    </message>
    <message>
        <source>Created By:</source>
        <translation>Създаден От:</translation>
    </message>
    <message>
        <source>Added On:</source>
        <translation>Добавен На:</translation>
    </message>
    <message>
        <source>Completed On:</source>
        <translation>Завършен На:</translation>
    </message>
    <message>
        <source>Created On:</source>
        <translation>Създаден На:</translation>
    </message>
    <message>
        <source>Torrent Hash:</source>
        <translation>Сигнатура на Торента:</translation>
    </message>
    <message>
        <source>Save Path:</source>
        <translation>Местоположение за Запис:</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Никога</translation>
    </message>
    <message>
        <source>%1 x %2 (have %3)</source>
        <comment>(torrent pieces) eg 152 x 4MB (have 25)</comment>
        <translation>%1 x %2 (средно %3)</translation>
    </message>
    <message>
        <source>%1 (%2 this session)</source>
        <translation>%1 (%2 тази сесия)</translation>
    </message>
    <message>
        <source>%1 (%2 max)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 max)</comment>
        <translation>%1 (%2 макс.)</translation>
    </message>
    <message>
        <source>%1 (%2 total)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 total)</comment>
        <translation>%1 (%2 общо)</translation>
    </message>
    <message>
        <source>%1 (%2 avg.)</source>
        <comment>%1 and %2 are speed rates, e.g. 200KiB/s (100KiB/s avg.)</comment>
        <translation>%1 (%2 средно)</translation>
    </message>
    <message>
        <source>Download limit:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Upload limit:</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <source>Monitored Folder</source>
        <translation>Наблюдавана Директория</translation>
    </message>
    <message>
        <source>Override Save Location</source>
        <translation>Преопределяне на Място на Запис</translation>
    </message>
    <message>
        <source>Monitored folder</source>
        <translation>Наблюдавана директория</translation>
    </message>
    <message>
        <source>Default save location</source>
        <translation>Местоположение за запис по подразбиране</translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
    <message>
        <source>KiB/s</source>
        <translation>KiB/с</translation>
    </message>
</context>
<context>
    <name>StatsDialog</name>
    <message>
        <source>Statistics</source>
        <translation>Статистики</translation>
    </message>
    <message>
        <source>User statistics</source>
        <translation>Потребителски статистики</translation>
    </message>
    <message>
        <source>Cache statistics</source>
        <translation>Статистика на кеша</translation>
    </message>
    <message>
        <source>Read cache hits:</source>
        <translation>Прочитане на кешираните попадения:</translation>
    </message>
    <message>
        <source>Average time in queue:</source>
        <translation>Осреднено време на опашка:</translation>
    </message>
    <message>
        <source>Connected peers:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>All-time share ratio:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>All-time download:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Session waste:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>All-time upload:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Total buffer size:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Performance statistics</source>
        <translation>Статистика на дейността</translation>
    </message>
    <message>
        <source>Queued I/O jobs:</source>
        <translation>Наредени на опашка В/И задачи:</translation>
    </message>
    <message>
        <source>Write cache overload:</source>
        <translation>Запиши кеша при претоварване:</translation>
    </message>
    <message>
        <source>Read cache overload:</source>
        <translation>Прочети кеша при претоварване:</translation>
    </message>
    <message>
        <source>Total queued size:</source>
        <translation>Общ размер на опашката:</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <source>DHT: %1 nodes</source>
        <translation>DHT: %1 възли</translation>
    </message>
</context>
<context>
    <name>StatusFilterWidget</name>
    <message>
        <source>All (0)</source>
        <comment>this is for the status filter</comment>
        <translation>Всички (0)</translation>
    </message>
    <message>
        <source>Downloading (0)</source>
        <translation>Свалящи се (0)</translation>
    </message>
    <message>
        <source>Seeding (0)</source>
        <translation>Споделящи се (0)</translation>
    </message>
    <message>
        <source>Completed (0)</source>
        <translation>Приключени (0)</translation>
    </message>
    <message>
        <source>Resumed (0)</source>
        <translation>Продължени (0)</translation>
    </message>
    <message>
        <source>Paused (0)</source>
        <translation>В Пауза (0)</translation>
    </message>
    <message>
        <source>Active (0)</source>
        <translation>Активни (0)</translation>
    </message>
    <message>
        <source>Inactive (0)</source>
        <translation>Неактивни (0)</translation>
    </message>
    <message>
        <source>Errored (0)</source>
        <translation>С грешки (0)</translation>
    </message>
    <message>
        <source>All (%1)</source>
        <translation>Всички (%1)</translation>
    </message>
    <message>
        <source>Downloading (%1)</source>
        <translation>Свалящи се (%1)</translation>
    </message>
    <message>
        <source>Seeding (%1)</source>
        <translation>Споделящи се (%1)</translation>
    </message>
    <message>
        <source>Completed (%1)</source>
        <translation>Приключени (%1)</translation>
    </message>
    <message>
        <source>Paused (%1)</source>
        <translation>В Пауза (%1)</translation>
    </message>
    <message>
        <source>Resumed (%1)</source>
        <translation>Продължени (%1)</translation>
    </message>
    <message>
        <source>Active (%1)</source>
        <translation>Активни (%1)</translation>
    </message>
    <message>
        <source>Inactive (%1)</source>
        <translation>Неактивни (%1)</translation>
    </message>
    <message>
        <source>Errored (%1)</source>
        <translation>С грешки (%1)</translation>
    </message>
</context>
<context>
    <name>TorrentContentModel</name>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Размер</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Изпълнение</translation>
    </message>
    <message>
        <source>Download Priority</source>
        <translation>Приоритет на Сваляне</translation>
    </message>
    <message>
        <source>Remaining</source>
        <translation>Остават</translation>
    </message>
    <message>
        <source>Availability</source>
        <translation>Наличност</translation>
    </message>
</context>
<context>
    <name>TransferListModel</name>
    <message>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation>Име</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation>Размер</translation>
    </message>
    <message>
        <source>Done</source>
        <comment>% Done</comment>
        <translation>Готово</translation>
    </message>
    <message>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation>Състояние</translation>
    </message>
    <message>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation>Споделящи</translation>
    </message>
    <message>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation>Участници</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Скорост Сваляне</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Скорост на качване</translation>
    </message>
    <message>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation>Съотношение</translation>
    </message>
    <message>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation>Оставащо време</translation>
    </message>
    <message>
        <source>Category</source>
        <translation>Категория</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>Етикети</translation>
    </message>
    <message>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation>Добавен на</translation>
    </message>
    <message>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation>Завършен на</translation>
    </message>
    <message>
        <source>Tracker</source>
        <translation>Тракер</translation>
    </message>
    <message>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation>Лимит сваляне</translation>
    </message>
    <message>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation>Лимит качване</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation>Свалени</translation>
    </message>
    <message>
        <source>Uploaded</source>
        <comment>Amount of data uploaded (e.g. in MB)</comment>
        <translation>Качени</translation>
    </message>
    <message>
        <source>Session Download</source>
        <comment>Amount of data downloaded since program open (e.g. in MB)</comment>
        <translation>Сваляне в Сесията</translation>
    </message>
    <message>
        <source>Session Upload</source>
        <comment>Amount of data uploaded since program open (e.g. in MB)</comment>
        <translation>Качване в Сесията</translation>
    </message>
    <message>
        <source>Remaining</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation>Оставащо</translation>
    </message>
    <message>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation>Време активен</translation>
    </message>
    <message>
        <source>Save path</source>
        <comment>Torrent save path</comment>
        <translation>Запазване на пътя</translation>
    </message>
    <message>
        <source>Completed</source>
        <comment>Amount of data completed (e.g. in MB)</comment>
        <translation>Приключено</translation>
    </message>
    <message>
        <source>Ratio Limit</source>
        <comment>Upload share ratio limit</comment>
        <translation>Ограничение на Коефицента</translation>
    </message>
    <message>
        <source>Last Seen Complete</source>
        <comment>Indicates the time when the torrent was last seen complete/whole</comment>
        <translation>Последно приключен</translation>
    </message>
    <message>
        <source>Last Activity</source>
        <comment>Time passed since a chunk was downloaded/uploaded</comment>
        <translation>Последна активност</translation>
    </message>
    <message>
        <source>Total Size</source>
        <comment>i.e. Size including unwanted data</comment>
        <translation>Пълен размер</translation>
    </message>
</context>
<context>
    <name>TrackerListWidget</name>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Състояние</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation>Участници</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Съобщение</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Tracker URL:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Updating...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Working</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Disabled</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Not contacted yet</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>#</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>N/A</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Seeds</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Not working</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Copy tracker URL</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add a new tracker...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Edit tracker URL...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Tracker editing</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Leeches</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Remove tracker</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>TrackersAdditionDialog</name>
    <message>
        <source>Trackers addition dialog</source>
        <translation>Допълнителен диалог на тракери</translation>
    </message>
    <message>
        <source>List of trackers to add (one per line):</source>
        <translation>Списък тракери за добавяне (по един на ред):</translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <source>%1 ago</source>
        <comment>e.g.: 1h 20m ago</comment>
        <translation>%1 по- рано</translation>
    </message>
    <message>
        <source>Allocating</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Paused</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Completed</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Moving</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>[F] Seeding</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Seeding</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Queued</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Errored</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>[F] Downloading</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Downloading metadata</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Checking</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Missing Files</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Queued for checking</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Downloading</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Checking resume data</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Stalled</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <source>Status</source>
        <translation>Състояние</translation>
    </message>
    <message>
        <source>Categories</source>
        <translation>Категории</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <source>Torrent Download Speed Limiting</source>
        <translation>Ограничаване Скорост на сваляне</translation>
    </message>
    <message>
        <source>Torrent Upload Speed Limiting</source>
        <translation>Ограничаване Скорост на качване</translation>
    </message>
    <message>
        <source>Rename</source>
        <translation>Преименувай</translation>
    </message>
    <message>
        <source>Resume</source>
        <comment>Resume/start the torrent</comment>
        <translation>Продължи</translation>
    </message>
    <message>
        <source>Force Resume</source>
        <comment>Force Resume/start the torrent</comment>
        <translation>Насилствено Продължение</translation>
    </message>
    <message>
        <source>Pause</source>
        <comment>Pause the torrent</comment>
        <translation>Пауза</translation>
    </message>
    <message>
        <source>Delete</source>
        <comment>Delete the torrent</comment>
        <translation>Изтрий</translation>
    </message>
    <message>
        <source>Limit share ratio...</source>
        <translation>Ограничение на съотношението за споделяне...</translation>
    </message>
    <message>
        <source>Limit upload rate...</source>
        <translation>Ограничи процент качване...</translation>
    </message>
    <message>
        <source>Limit download rate...</source>
        <translation>Ограничи процент сваляне...</translation>
    </message>
    <message>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>Нагоре в листата</translation>
    </message>
    <message>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>Надолу в листата</translation>
    </message>
    <message>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>На върха на листата</translation>
    </message>
    <message>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>На дъното на листата</translation>
    </message>
    <message>
        <source>Set location...</source>
        <translation>Определи място...</translation>
    </message>
    <message>
        <source>Copy name</source>
        <translation>Копиране на име</translation>
    </message>
    <message>
        <source>Copy hash</source>
        <translation>Копиране на контролната сума</translation>
    </message>
    <message>
        <source>Download first and last pieces first</source>
        <translation>Сваляне първо на първото и последното парче</translation>
    </message>
    <message>
        <source>Automatic Torrent Management</source>
        <translation>Автоматичен Торентов Режим на Управаление</translation>
    </message>
    <message>
        <source>Category</source>
        <translation>Категория</translation>
    </message>
    <message>
        <source>New...</source>
        <comment>New category...</comment>
        <translation>Нов...</translation>
    </message>
    <message>
        <source>Reset</source>
        <comment>Reset category</comment>
        <translation>Нулиране</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Предимство</translation>
    </message>
    <message>
        <source>Force recheck</source>
        <translation>Включени проверки за промени</translation>
    </message>
    <message>
        <source>Copy magnet link</source>
        <translation>Копирай връзка magnet</translation>
    </message>
    <message>
        <source>Super seeding mode</source>
        <translation>Режим на супер-даване</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Преименувай...</translation>
    </message>
    <message>
        <source>Download in sequential order</source>
        <translation>Сваляне по азбучен ред</translation>
    </message>
    <message>
        <source>Force Recheck</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>New Category</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Location</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>New name</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Set location</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Force reannounce</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Edit Category</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Save path</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>UpDownRatioDialog</name>
    <message>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation>Ограничение на съотношението Сваляне/Качване на торента</translation>
    </message>
    <message>
        <source>Use global share limit</source>
        <translation>Използване на общото ограничение на споделяне</translation>
    </message>
    <message>
        <source>Set no share limit</source>
        <translation>Задаване без ограничение на споделяне</translation>
    </message>
    <message>
        <source>Set share limit to</source>
        <translation>Задаване на ограничение за споделяне на</translation>
    </message>
    <message>
        <source>ratio</source>
        <translation>съотношение</translation>
    </message>
    <message>
        <source>minutes</source>
        <translation>минути</translation>
    </message>
</context>
<context>
    <name>about</name>
    <message>
        <source>An advanced BitTorrent client programmed in C++, based on Qt toolkit and libtorrent-rasterbar.</source>
        <translation>Разширен BitTorrent клиент написан на C++, базиран на Qt toolkit и libtorrent-rasterbar.</translation>
    </message>
    <message>
        <source>Home Page:</source>
        <translation>Първоначална страница:</translation>
    </message>
    <message>
        <source>Forum:</source>
        <translation>Форум:</translation>
    </message>
    <message>
        <source>Bug Tracker:</source>
        <translation>Докладване на грешки:</translation>
    </message>
</context>
<context>
    <name>confirmDeletionDlg</name>
    <message>
        <source>Deletion confirmation</source>
        <translation>Потвърждение за изтриване</translation>
    </message>
    <message>
        <source>Also delete the files on the hard disk</source>
        <translation>Също изтрий файловете от твърдия диск</translation>
    </message>
    <message>
        <source>Deletion confirmation - qBittorrent</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>downloadFromURL</name>
    <message>
        <source>Download from URLs</source>
        <translation>Сваляне от URL-ове</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Свали</translation>
    </message>
    <message>
        <source>Add Torrent Links</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <source>B</source>
        <comment>bytes</comment>
        <translation>Б</translation>
    </message>
    <message>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>КБ</translation>
    </message>
    <message>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>МБ</translation>
    </message>
    <message>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>ГБ</translation>
    </message>
    <message>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>ТБ</translation>
    </message>
    <message>
        <source>PiB</source>
        <comment>pebibytes (1024 tebibytes)</comment>
        <translation>PiB</translation>
    </message>
    <message>
        <source>EiB</source>
        <comment>exbibytes (1024 pebibytes)</comment>
        <translation>EiB</translation>
    </message>
    <message>
        <source>/s</source>
        <comment>per second</comment>
        <translation>/с</translation>
    </message>
    <message>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation>%1ч%2мин</translation>
    </message>
    <message>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation>%1д%2ч</translation>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>Неизвестен</translation>
    </message>
    <message>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt; 1мин</translation>
    </message>
    <message>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1мин</translation>
    </message>
</context>
<context>
    <name>TorrentsController</name>
    <message>
        <source>Save path is empty</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>PluginSourceDlg</name>
    <message>
        <source>Cancel</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Plugin path:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>URL or local directory</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Install plugin</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Ok</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>SearchEngineWidget</name>
    <message>
        <source>Seeds:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>All plugins</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Size:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Stop</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Search</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Search plugins...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>All categories</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Search in:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Copy description page URL</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Go to description page</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Results (showing</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Download</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Filter</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Torrent names only</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Only enabled</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>out of</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Everywhere</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>PluginSelectDlg</name>
    <message>
        <source>Uninstall</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Install new plugin</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>You can get new search engine plugins here:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Installed search plugins:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Enabled</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Warning: Be sure to comply with your country's copyright laws when downloading torrents from any of these search engines.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Check for updates</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Search plugins</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>SearchResultsTable</name>
    <message>
        <source>Name</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Size</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Leechers</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Search engine</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Seeders</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>SearchPluginsTable</name>
    <message>
        <source>Name</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Url</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Enabled</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Version</source>
        <translation type="unfinished" />
    </message>
</context>
</TS>